/* ========================================================================== */
/*                                                                            */
/*   Filename.c                                                               */
/*   (c) 2012 Author                                                          */
/*                                                                            */
/*   Description                                                              */
/*                                                                            */
/* ========================================================================== */

#ifndef Breath_h
#define Breath_h
#include <Arduino.h>

//#include and code here

class Breath{
   public: 
       Breath(int pin);  //Constructor. attach pin to blink
       void breath(bool value, int blinkLength);   //��ǰ���ȼ���ά�ֵ�ʱ��,��λ���� blink duration  
       void breath(bool value,int light, int blinkLength);   //��ǰ���ȼ���:light;ά�ֵ�ʱ��,blinkLength��λ���� blink duration 
 private: 
        uint8_t pinNumber;
      }; 
#endif
